
from datetime import datetime, date, time
import argparse, os, sys
from argparse import RawTextHelpFormatter,SUPPRESS


#------------------------------ Colors For Print Statements ------------------------------#
class color:
   PURPLE = '\033[95m'
   CYAN = '\033[96m'
   DARKCYAN = '\033[36m'
   ORANGE = '\033[38;5;214m'
   BLUE = '\033[94m'
   GREEN = '\033[92m'
   YELLOW = '\033[93m'
   RED = '\033[91m'
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'



def check_args():

	parser = argparse.ArgumentParser(description=
	color.BOLD+'\nThis script will parse (and summarize) the outputs from\nthe tree-walking '\
	'scripts from the KatzLab phylogenomic pipeline.\n'+color.END+usage_msg(), 
	usage=SUPPRESS,formatter_class=RawTextHelpFormatter)
	
	required_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Required Options'+color.END)

	required_arg_group.add_argument('--input_file','-in', action='store',
	help=color.BOLD+color.GREEN+" Fasta file of Protein/Nucleotide sequences\n"+color.END)
	required_arg_group.add_argument('--output_file','-out',
	help=color.BOLD+color.GREEN+" Desired Output Name (must include 'rna' and minimum length)\n"+color.END)
	
	optional_arg_group = parser.add_argument_group(color.ORANGE+color.BOLD+'Options'+color.END)

	optional_arg_group.add_argument('-author', action='store_true',
	help=color.BOLD+color.GREEN+' Print author contact information\n'+color.END)
	
	if len(sys.argv[1:]) == 0:
		print (parser.description)
		print ('\n')
		sys.exit()

	args = parser.parse_args()

	more_info = return_more_info(args)
	if more_info != None:
		print (parser.description)
		print (more_info)
		sys.exit()	

	args = parser.parse_args()
	
	return args

###########################################################################################
###------------------------------- Script Usage Message --------------------------------###
###########################################################################################

def usage_msg():
	return color.BOLD+color.RED+'\n\nExample usage:'+color.CYAN+' python ParseTreeSummary.py'\
	' --input_file MyTreeSummary.txt --output_file DesiredOutputSummaryName '+color.END


##########################################################################################
###-------- Storage for LARGE (Annoying) Print Statements for Flagged Options ---------###
##########################################################################################

def return_more_info(args):

	author = (color.BOLD+color.ORANGE+'\n\n\tQuestions/Comments? Email Xyrus (author) at'\
	' maurerax@gmail.com\n\n'+color.END)

	if args.author == True:
		return author

def prep_folders():
	
	if os.path.isdir('../ContamByTaxon') != True:
		os.system('mkdir ../ContamByTaxon/')



def parse_TreeWalk_sisters(args):
	inSummary = [i for i in open(args.input_file).read().split('\n') if i.split('\t')[0] != '' and i.split('\t')[1] != '']

	taxa_of_interest = inSummary[0].split('\t')[1][:5]

	TreeContam_Dict = {i.split('\t')[1]:[[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]] for i in inSummary}

	try:
		TreeContam_Dict.pop('',None)
	except:
		pass

	current_date = datetime.now().strftime('%d_%m_%Y')
	supported_states = ['same','Sr_ap','Sr_ci','Sr_di','Sr_pe','Sr_st','Sr_rh','Pl_','EE_ha','EE_cr','EE_ce','Ex_','Am_','Op_fu','Op_me','Op_ch','Ba_','Za_','non-monophyletic','Other']	
	
	for i in inSummary:
		if 'same' in i.split('\t')[3]:
			TreeContam_Dict[i.split('\t')[1]][0].append(1)
		elif 'Sr_ap' in i.split('\t')[3] and 'Sr_ap' != taxa_of_interest:
			TreeContam_Dict[i.split('\t')[1]][1].append(1)
		elif 'Sr_ci' in i.split('\t')[3] and 'Sr_ci' != taxa_of_interest:
			TreeContam_Dict[i.split('\t')[1]][1].append(1)
		elif 'Sr_di' in i.split('\t')[3] and 'Sr_di' != taxa_of_interest:
			TreeContam_Dict[i.split('\t')[1]][2].append(1)
		elif 'Sr_pe' in i.split('\t')[3] and 'Sr_pe' != taxa_of_interest:
			TreeContam_Dict[i.split('\t')[1]][3].append(1)
		elif 'Sr_st' in i.split('\t')[3] and 'Sr_rh' != taxa_of_interest:
			TreeContam_Dict[i.split('\t')[1]][4].append(1)
		elif 'Sr_rh' in i.split('\t')[3] and 'Sr_st' != taxa_of_interest:
			TreeContam_Dict[i.split('\t')[1]][5].append(1)
		elif 'Pl_' in i.split('\t')[3]:
			TreeContam_Dict[i.split('\t')[1]][6].append(1)
		elif 'EE_ha' in i.split('\t')[3]:
			TreeContam_Dict[i.split('\t')[1]][7].append(1)
		elif 'EE_cr' in i.split('\t')[3]:
			TreeContam_Dict[i.split('\t')[1]][8].append(1)
		elif 'EE_ce' in i.split('\t')[3]:
			TreeContam_Dict[i.split('\t')[1]][9].append(1)
		elif 'Ex_' in i.split('\t')[3]:
			TreeContam_Dict[i.split('\t')[1]][10].append(1)
		elif 'Am_' in i.split('\t')[3]:
			TreeContam_Dict[i.split('\t')[1]][11].append(1)
		elif 'Op_fu' in i.split('\t')[3]:
			TreeContam_Dict[i.split('\t')[1]][12].append(1)
		elif 'Op_me' in i.split('\t')[3]:
			TreeContam_Dict[i.split('\t')[1]][13].append(1)
		elif 'Op_ch' in i.split('\t')[3]:
			TreeContam_Dict[i.split('\t')[1]][14].append(1)
		elif 'Ba_' in i.split('\t')[3]:
			TreeContam_Dict[i.split('\t')[1]][15].append(1)
		elif 'Za_' in i.split('\t')[3]:
			TreeContam_Dict[i.split('\t')[1]][16].append(1)
		elif 'non-monophyletic' in i.split('\t')[3]:
			TreeContam_Dict[i.split('\t')[1]][17].append(1)
		else:
			TreeContam_Dict[i.split('\t')[1]][18].append(1)

	TreeContam_ToSort = [k+'\t'+'\t'.join([str(sum(i)) for i in v])+'\t'+str(sum([sum(i) for i in v]))+'\n' for k,v in TreeContam_Dict.items()]
	TreeContam_ToSort.sort(key=lambda x: x.split('\t')[0])

	with open(args.output_file+'.TreeContam.'+current_date+'.tsv','w+') as w:
		supported_states.remove(taxa_of_interest)
		w.write('Taxon\t'+'\t'.join(supported_states)+'\tTotal\n')
		for line in TreeContam_ToSort:
			w.write(line+'\n')	

	print '\n\nOutput file: '+args.output_file+'.TreeContam.'+current_date+'.tsv\n\n'
	
	return TreeContam_ToSort


def Isolate_Putative_Contaminants(TreeContam, args):

	current_date = datetime.now().strftime('%d_%m_%Y')

	taxa_maybe_contam = {}

	for entry in TreeContam:
		if sum([int(i) for i in entry.split('\t')[1:-3]]) > 0:
			taxa_maybe_contam[entry.split('\t')[0]] = []
	
	inSummary = [i for i in open(args.input_file).read().split('\n') if i.split('\t')[0] != '' and i.split('\t')[1] != '']

	for i in inSummary:
		if i.split('\t')[1] in taxa_maybe_contam.keys() and 'same_minor' not in i and 'non-monophyletic' not in i:
			taxa_maybe_contam[i.split('\t')[1]].append(i)
				
	for k, v in taxa_maybe_contam.items():
		with open('../ContamByTaxon/'+k+'.Contam.'+current_date+'.tsv','w+') as w:
			w.write('\n'.join(v))


def main():

	args = check_args()
	
	prep_folders()
	
	TreeContam = parse_TreeWalk_sisters(args)

	Isolate_Putative_Contaminants(TreeContam, args)	
	
main()





